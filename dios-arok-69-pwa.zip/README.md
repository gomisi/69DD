
# Diós Árok 69 – PWA verzió

## Telepítés laptopon (Windows/macOS):
1. Csomagold ki a zip fájlt
2. Parancssorban navigálj a mappába
3. Futtasd: `npm install` majd `npm start`
4. Nyisd meg a böngészőt: http://localhost:3000

## iPhone telepítés:
1. Nyisd meg Safari-ban a `index.html`-t helyi szerverről
2. Használd a „Hozzáadás a Főképernyőhöz” opciót
3. Települ mint natív alkalmazás

Készen áll további funkciók hozzáadására.
